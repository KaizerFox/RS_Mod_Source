﻿namespace RobloxStudioModManager
{
    partial class ExplorerIconEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.iconContainer = new System.Windows.Forms.FlowLayoutPanel();
            this.selectIcon = new System.Windows.Forms.Label();
            this.enableIconOverride = new System.Windows.Forms.CheckBox();
            this.editIcon = new System.Windows.Forms.Button();
            this.selectedIcon = new System.Windows.Forms.PictureBox();
            this.restoreOriginal = new System.Windows.Forms.Button();
            this.themeSwitcher = new System.Windows.Forms.Button();
            this.memoryStatus = new System.Windows.Forms.Label();
            this.studioStatus = new System.Windows.Forms.Label();
            this.errors = new System.Windows.Forms.Label();
            this.showModified = new System.Windows.Forms.CheckBox();
            this.openIconFolder = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.selectedIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // iconContainer
            // 
            this.iconContainer.AutoScroll = true;
            this.iconContainer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.iconContainer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.iconContainer.Location = new System.Drawing.Point(16, 34);
            this.iconContainer.Margin = new System.Windows.Forms.Padding(4);
            this.iconContainer.MaximumSize = new System.Drawing.Size(361, 12306);
            this.iconContainer.Name = "iconContainer";
            this.iconContainer.Padding = new System.Windows.Forms.Padding(0, 0, 13, 0);
            this.iconContainer.Size = new System.Drawing.Size(344, 208);
            this.iconContainer.TabIndex = 0;
            // 
            // selectIcon
            // 
            this.selectIcon.AutoSize = true;
            this.selectIcon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectIcon.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.selectIcon.Location = new System.Drawing.Point(11, 5);
            this.selectIcon.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.selectIcon.Name = "selectIcon";
            this.selectIcon.Size = new System.Drawing.Size(120, 25);
            this.selectIcon.TabIndex = 2;
            this.selectIcon.Text = "Select Icon";
            // 
            // enableIconOverride
            // 
            this.enableIconOverride.AutoSize = true;
            this.enableIconOverride.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.enableIconOverride.Location = new System.Drawing.Point(85, 256);
            this.enableIconOverride.Margin = new System.Windows.Forms.Padding(4);
            this.enableIconOverride.Name = "enableIconOverride";
            this.enableIconOverride.Size = new System.Drawing.Size(115, 21);
            this.enableIconOverride.TabIndex = 4;
            this.enableIconOverride.Text = "Override Icon";
            this.enableIconOverride.UseVisualStyleBackColor = true;
            this.enableIconOverride.CheckedChanged += new System.EventHandler(this.enableIconOverride_CheckedChanged);
            // 
            // editIcon
            // 
            this.editIcon.BackColor = System.Drawing.Color.Black;
            this.editIcon.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.editIcon.Location = new System.Drawing.Point(84, 282);
            this.editIcon.Margin = new System.Windows.Forms.Padding(4);
            this.editIcon.Name = "editIcon";
            this.editIcon.Size = new System.Drawing.Size(120, 28);
            this.editIcon.TabIndex = 5;
            this.editIcon.Text = "Edit Icon 0";
            this.editIcon.UseVisualStyleBackColor = false;
            this.editIcon.Click += new System.EventHandler(this.editIcon_Click);
            // 
            // selectedIcon
            // 
            this.selectedIcon.BackColor = System.Drawing.Color.Black;
            this.selectedIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.selectedIcon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.selectedIcon.Location = new System.Drawing.Point(16, 254);
            this.selectedIcon.Margin = new System.Windows.Forms.Padding(4);
            this.selectedIcon.Name = "selectedIcon";
            this.selectedIcon.Size = new System.Drawing.Size(60, 56);
            this.selectedIcon.TabIndex = 3;
            this.selectedIcon.TabStop = false;
            this.selectedIcon.WaitOnLoad = true;
            // 
            // restoreOriginal
            // 
            this.restoreOriginal.BackColor = System.Drawing.Color.Black;
            this.restoreOriginal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.restoreOriginal.Enabled = false;
            this.restoreOriginal.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.restoreOriginal.Location = new System.Drawing.Point(212, 282);
            this.restoreOriginal.Margin = new System.Windows.Forms.Padding(4);
            this.restoreOriginal.Name = "restoreOriginal";
            this.restoreOriginal.Size = new System.Drawing.Size(149, 28);
            this.restoreOriginal.TabIndex = 6;
            this.restoreOriginal.Text = "Restore Original";
            this.restoreOriginal.UseCompatibleTextRendering = true;
            this.restoreOriginal.UseVisualStyleBackColor = false;
            this.restoreOriginal.Click += new System.EventHandler(this.restoreOriginal_Click);
            // 
            // themeSwitcher
            // 
            this.themeSwitcher.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.themeSwitcher.Cursor = System.Windows.Forms.Cursors.Hand;
            this.themeSwitcher.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.themeSwitcher.Location = new System.Drawing.Point(212, 251);
            this.themeSwitcher.Margin = new System.Windows.Forms.Padding(4);
            this.themeSwitcher.Name = "themeSwitcher";
            this.themeSwitcher.Size = new System.Drawing.Size(149, 28);
            this.themeSwitcher.TabIndex = 7;
            this.themeSwitcher.Text = "Theme: Light";
            this.themeSwitcher.UseCompatibleTextRendering = true;
            this.themeSwitcher.UseVisualStyleBackColor = false;
            this.themeSwitcher.Click += new System.EventHandler(this.themeSwitcher_Click);
            // 
            // memoryStatus
            // 
            this.memoryStatus.AutoSize = true;
            this.memoryStatus.Location = new System.Drawing.Point(12, 319);
            this.memoryStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.memoryStatus.Name = "memoryStatus";
            this.memoryStatus.Size = new System.Drawing.Size(178, 17);
            this.memoryStatus.TabIndex = 8;
            this.memoryStatus.Text = "Memory Budget: Loading...";
            // 
            // studioStatus
            // 
            this.studioStatus.AutoSize = true;
            this.studioStatus.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.studioStatus.Location = new System.Drawing.Point(12, 335);
            this.studioStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.studioStatus.Name = "studioStatus";
            this.studioStatus.Size = new System.Drawing.Size(163, 17);
            this.studioStatus.TabIndex = 9;
            this.studioStatus.Text = "Studio Status: Loading...";
            // 
            // errors
            // 
            this.errors.AutoSize = true;
            this.errors.ForeColor = System.Drawing.Color.Red;
            this.errors.Location = new System.Drawing.Point(12, 357);
            this.errors.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.errors.Name = "errors";
            this.errors.Size = new System.Drawing.Size(0, 17);
            this.errors.TabIndex = 10;
            // 
            // showModified
            // 
            this.showModified.AutoSize = true;
            this.showModified.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.showModified.Location = new System.Drawing.Point(195, 9);
            this.showModified.Margin = new System.Windows.Forms.Padding(4);
            this.showModified.Name = "showModified";
            this.showModified.Size = new System.Drawing.Size(158, 21);
            this.showModified.TabIndex = 11;
            this.showModified.Text = "Show Modified Icons";
            this.showModified.UseVisualStyleBackColor = true;
            this.showModified.CheckedChanged += new System.EventHandler(this.showModified_CheckedChanged);
            // 
            // openIconFolder
            // 
            this.openIconFolder.BackColor = System.Drawing.Color.Black;
            this.openIconFolder.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.openIconFolder.Location = new System.Drawing.Point(16, 401);
            this.openIconFolder.Margin = new System.Windows.Forms.Padding(4);
            this.openIconFolder.Name = "openIconFolder";
            this.openIconFolder.Size = new System.Drawing.Size(345, 28);
            this.openIconFolder.TabIndex = 12;
            this.openIconFolder.Text = "Open Explorer Icon Folder";
            this.openIconFolder.UseVisualStyleBackColor = false;
            this.openIconFolder.Click += new System.EventHandler(this.openIconFolder_Click);
            // 
            // ExplorerIconEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(379, 444);
            this.Controls.Add(this.openIconFolder);
            this.Controls.Add(this.showModified);
            this.Controls.Add(this.errors);
            this.Controls.Add(this.studioStatus);
            this.Controls.Add(this.memoryStatus);
            this.Controls.Add(this.themeSwitcher);
            this.Controls.Add(this.restoreOriginal);
            this.Controls.Add(this.editIcon);
            this.Controls.Add(this.enableIconOverride);
            this.Controls.Add(this.selectedIcon);
            this.Controls.Add(this.selectIcon);
            this.Controls.Add(this.iconContainer);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = global::RobloxStudioModManager.Properties.Resources.Icon;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "ExplorerIconEditor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "R.S. Icon Editor";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.ExplorerIconEditor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.selectedIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel iconContainer;
        private System.Windows.Forms.Label selectIcon;
        private System.Windows.Forms.CheckBox enableIconOverride;
        private System.Windows.Forms.Button editIcon;
        private System.Windows.Forms.PictureBox selectedIcon;
        private System.Windows.Forms.Button restoreOriginal;
        private System.Windows.Forms.Button themeSwitcher;
        private System.Windows.Forms.Label memoryStatus;
        private System.Windows.Forms.Label studioStatus;
        private System.Windows.Forms.Label errors;
        private System.Windows.Forms.CheckBox showModified;
        private System.Windows.Forms.Button openIconFolder;
    }
}